/*
GABRIEL_FELIPE_REZENDE_DE_JESUS
2-Um programa que calcule a �rea do tri�ngulo.
14/03/2023
*/

#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main(void) {
	setlocale(LC_ALL, "Portuguese");
	
	float b, h, area;
	
//----------------------------------------------------------------------------------------------------------------

	printf("\n");
	printf("\t\t---------------------- CALCULADORA DE �REA DO TRI�NGULO ----------------------");
	printf("\n\n");

	
//----------------------------------------------------------------------------------------------------------------

	printf("Informe a medida da base do tri�ngulo em 'cm' (utilize '.' no lugar de ',' para decimais): ");
	scanf("%f",&b);
	
	printf("Informe a medida da altura do tri�ngulo em 'cm' (utilize '.' no lugar de ',' para decimais): ");
	scanf("%f",&h);
	
//----------------------------------------------------------------------------------------------------------------
	
	area = (b*h)/2;
	
	printf("\n");
	printf("A �rea do tri�ngulo �: %.2fcm�", area);
	printf("\n");
	
	
	return 0;
}
