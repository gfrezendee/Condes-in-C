/*
GABRIEL_FELIPE_REZENDE_DE_JESUS
5-Fa�a um programa em C que leia a nota final, o total de presen�as e o n�mero total de
aulas ministradas e imprima a nota final, o total de presen�as e uma mensagem dizendo se
este aluno foi aprovado ou reprovado. Sabe-se que a freq��ncia necess�ria � de no m�nimo
75% das aulas ministradas e que a nota m�nima deve ser maior ou igual a 6.0.
14/03/2023
*/

#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main(void) {
	setlocale(LC_ALL, "Portuguese");
	
	printf("\n");
	printf("\t\t---------------------- CALCULADORA DE RESULTADO FINAL ----------------------");
	printf("\n\n");
	
//----------------------------------------------------------------------------------------------------------------

	float nota;
	int presenca, aulas, freq;
	
//----------------------------------------------------------------------------------------------------------------
	
	printf("Informe a nota final do aluno: ");
	scanf("%f",&nota);
	
	printf("Informe o total de presen�as do aluno: ");
	scanf("%i",&presenca);
	
	printf("Informe o total de aulas ministradas: ");
	scanf("%i",&aulas);
	
	
//----------------------------------------------------------------------------------------------------------------

	freq = aulas * 0.75;
	
	if(presenca >= freq && nota >= 6.0){
		printf("\n\tO aluno est� aprovado!\n");
	}else{
		printf("\n\tO aluno est� reprovado!\n");
	}
	
	return 0;
}
