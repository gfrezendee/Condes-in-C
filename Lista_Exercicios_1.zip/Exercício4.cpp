/*
GABRIEL_FELIPE_REZENDE_DE_JESUS
4-Fa�a um programa que entra com a idade de uma pessoa e se idade maior que 70 anos,
aparece a mensagem Velho. Se idade maior que 21 anos, Adulto. Se idade menor que 21
anos, Jovem.
14/03/2023
*/

#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main(void) {
	setlocale(LC_ALL, "Portuguese");
	
	int idade;
	
	printf("Informe uma idade: ");
	scanf("%i",&idade);
	
	if(idade >= 70){
		printf("Velho.");
		
	}else if(idade >= 21){
		printf("Adulto.");
		
	} else if(idade < 21){
		printf("Jovem.");
	}
	
	
	return 0;
}
