/*
GABRIEL_FELIPE_REZENDE_DE_JESUS
6-Fa�a um algoritmo recebe um valor inteiro e se o n�mero for maior que 10, ser� impressa a
frase: "O n�mero e maior que 10". Se o n�mero for menor que 10, ser� impressa a frase:
�O n�mero � menor que 10�. Se o n�mero for igual a 10 aparecer� a frase: �Voc� acertou�. 
14/03/2023
*/

#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main(void) {
	setlocale(LC_ALL, "Portuguese");
	
	int x;
	
	printf("Informe um n�mero inteiro: ");
	scanf("%i",&x);
	
	if(x < 10){
		printf("O n�mero � menor que 10!");
	}else if(x > 10){
		printf("O n�mero � maior que 10!");
	} else if(x = 10){
		printf("Voc� acertou!");
	}
	
	return 0;
}
