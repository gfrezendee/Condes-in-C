/*
GABRIEL_FELIPE_REZENDE_DE_JESUS
3-Fa�a um programa que recebe a idade de uma pessoa e se idade menor que 30 aparece a
mensagem Voc� � muito jovem. Caso idade maior que 30 anos, o programa n�o far� nada.
14/03/2023
*/

#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main(void) {
	setlocale(LC_ALL, "Portuguese");
	
	int idade;
	
	printf("Informe sua idade: ");
	scanf("%i",&idade);
	
	if(idade < 30){
		printf("Voc� � muito jovem!");
	}else{
	}
	
	return 0;
}
