/*
GABRIEL_FELIPE_REZENDE_DE_JESUS
1-Programa que calcule a m�dia de 5 notas de um aluno.
14/03/2023
*/

#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main(void) {
	
	float nota1, nota2, nota3, nota4, nota5, media;
	
	setlocale(LC_ALL, "Portuguese");
	
//----------------------------------------------------------------------------------------------------------------
	
	printf("\n");
	printf("\t\t---------------------- CALCULADORA DE M�DIA ----------------------");
	printf("\n\n");
	
//----------------------------------------------------------------------------------------------------------------
	
	printf("Informe a primeira nota (utilize '.' no lugar de ',' para decimais): ");
	scanf("%f",&nota1);
	
	printf("Informe a segunda nota (utilize '.' no lugar de ',' para decimais): ");
	scanf("%f",&nota2);
	
	printf("Informe a terceira nota (utilize '.' no lugar de ',' para decimais): ");
	scanf("%f",&nota3);
	
	printf("Informe a quarta nota (utilize '.' no lugar de ',' para decimais): ");
	scanf("%f",&nota4);
	
	printf("Informe a quinta nota (utilize '.' no lugar de ',' para decimais): ");
	scanf("%f",&nota5);
	
//----------------------------------------------------------------------------------------------------------------
	
	if(nota1 > 10 || nota2 > 10 || nota3 > 10 || nota4 > 10 || nota5 > 10){
		printf("Nota inv�lida!");
		return 0;
	}else{
		media = (nota1 + nota2 + nota3 + nota4 + nota5)/5;
	
	printf("\n");
	printf("A media �: %.2f", media);
	printf("\n");
	
	
	if(media >= 7){
		printf("Aluno APROVADO!");
	}else if (media >= 4){
		printf("Aluno apto para RECUPERA��O!");
	}else{
		printf("Aluno REPROVADO!");
	}
}
	
	return 0;
}
