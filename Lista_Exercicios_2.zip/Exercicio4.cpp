/*
GABRIEL_FELIPE_REZENDE_DE_JESUS
4- Leia quatro valores inteiros A, B, C e D. A seguir, calcule e mostre a diferen�a do produto
de A e B pelo produto de C e D segundo a f�rmula: DIFERENCA = (A * B - C * D).
14/03/2023
*/

#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main(void) {
	
	setlocale(LC_ALL, "Portuguese");
	
	int A, B, C, D, DIFERENCA;
	
	printf("Informe um valor inteiro para 'A': ");
	scanf("%i",&A);
	
	printf("Informe um valor inteiro para 'B': ");
	scanf("%i",&B);
	
	printf("Informe um valor inteiro para 'C': ");
	scanf("%i",&C);
	
	printf("Informe um valor inteiro para 'D': ");
	scanf("%i",&D);
	
	DIFERENCA = (A*B - C*D);
	
	printf("\n");
	printf("DIFERENCA = %i",DIFERENCA);
	printf("\n");
	
	return 0;
}
