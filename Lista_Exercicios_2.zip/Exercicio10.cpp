/*
GABRIEL_FELIPE_REZENDE_DE_JESUS
10- Fa�a um algoritmo que leia um n�mero N e imprima �F1�, �F2� ou �F3�, conforme a
condi��o:
- �F1�, se N <= 10
- �F2�, se N > 10 e N <= 100
- �F3�se n > 100
21/03/2023
*/

#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main(void) {
  int n;

   printf("Valor de N: ");
   scanf("%i",&n);

   if(n <= 10){
   printf("F1");
   }else if (n > 10 && n <= 100){
   	printf("F2");
   }else{
   	printf("F3");
   }

    return 0;
}
