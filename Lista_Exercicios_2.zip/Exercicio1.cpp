/*
GABRIEL_FELIPE_REZENDE_DE_JESUS
1- Leia 2 valores inteiros e armazene-os nas vari�veis A e B. Efetue a soma
de A e B atribuindo o seu resultado na vari�vel X. Imprima X conforme exemplo
apresentado abaixo. N�o apresente mensagem alguma al�m daquilo que est� sendo
especificado.
14/03/2023
*/

#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main(void) {
	
	setlocale(LC_ALL, "Portuguese");
	
	int A, B, X;
	
	printf("Informe um valor inteiro para 'A': ");
	scanf("%i",&A);
	
	printf("Informe um valor inteiro para 'B': ");
	scanf("%i",&B);
	
	X = A+B;
	
	printf("\n");
	printf("X = %i",X);
	printf("\n");
	
	return 0;
}
