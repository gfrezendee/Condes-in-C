/*
GABRIEL_FELIPE_REZENDE_DE_JESUS
9- Fa�a um algoritmo que leia dois n�meros A e B e imprima o maior deles.
21/03/2023
*/

#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main(void) {
	setlocale (LC_ALL, "Portuguese");

	float a,b;

  scanf("%f",&a);
  scanf("%f",&b);
  if(b > a){
    printf("%f",b);
  }else{
	printf("%f", a);
	}

  return 0;
}
