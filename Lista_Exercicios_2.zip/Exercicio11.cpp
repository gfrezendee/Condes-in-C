/*
GABRIEL_FELIPE_REZENDE_DE_JESUS
11- Construa um algoritmo que receba como entrada tr�s valores e os imprima em ordem
crescente. 
21/03/2023
*/

#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main(void) {
 float v;
 
	scanf("%f",&v);

	if (v > 50000){
    	printf("%f", v * 0.12);
	}else (v >= 30000 and v <= 50000){
    	printf("%f",v * 0.95);
	}
	if(v >= 0){
    	printf("%f",v * 0.7);
  	}else{
	  }
    
	return 0;
}
