/*
GABRIEL_FELIPE_REZENDE_DE_JESUS
6- Neste problema, deve-se ler o c�digo de uma pe�a 1, o n�mero de pe�as 1, o valor
unit�rio de cada pe�a 1, o c�digo de uma pe�a 2, o n�mero de pe�as 2 e o valor unit�rio
de cada pe�a 2. Ap�s, calcule e mostre o valor a ser pago.
14/03/2023
*/

#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main(void) {
	
	setlocale(LC_ALL, "Portuguese");
	
	float cod1, n1, val1, cod2, n2, val2, total;
	
	printf("Informe o c�digo da primeira pe�a: ");
	scanf("%f",&cod1);
	
	printf("Informe a quantidade de pe�as: ");
	scanf("%f",&n1);
	
	printf("Informe o valor da pe�a: ");
	scanf("%f",&val1);
	
	printf("Informe o c�digo da segunda pe�a: ");
	scanf("%f",&cod2);
	
	printf("Informe a quantidade de pe�as: ");
	scanf("%f",&n2);
	
	printf("Informe o valor da pe�a: ");
	scanf("%f",&val2);
	
	total = (val1*n1) + (val2*n2);
	
	printf("\n");
	printf("VALOR A PAGAR = %.2f",total);
	printf("\n");
	
	return 0;
}
