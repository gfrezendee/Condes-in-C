/*
GABRIEL_FELIPE_REZENDE_DE_JESUS
7- Fa�a um programa que calcule e mostre o volume de uma esfera sendo fornecido o
valor de seu raio (R). A f�rmula para calcular o volume �: (4/3) * pi * R3. Considere (atribua) para pi o valor 3.14159.
14/03/2023
*/

#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main(void) {
	
	setlocale(LC_ALL, "Portuguese");
	
	double R, pi, V, div;
	pi = 3.14159;
	div= 1.33333;
	
	
	printf("Informe o raio da esfera: ");
	scanf("%lf",&R);
	
	V = div*pi*(R*R*R);
	
	printf("\n");
	printf("VOLUME = %.4lf",V);
	printf("\n");
	
	return 0;
}
