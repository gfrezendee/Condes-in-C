/*
GABRIEL_FELIPE_REZENDE_DE_JESUS
3- Leia dois valores inteiros. A seguir, calcule o produto entre estes dois valores e atribua
esta opera��o � vari�vel PROD. A seguir mostre a vari�vel PROD com mensagem
correspondente.
14/03/2023
*/

#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main(void) {
	
	setlocale(LC_ALL, "Portuguese");
	
	int A, B, PROD;
	
	printf("Informe um valor inteiro para 'A': ");
	scanf("%i",&A);
	
	printf("Informe um valor inteiro para 'B': ");
	scanf("%i",&B);
	
	PROD = A*B;
	
	printf("\n");
	printf("PROD = %i",PROD);
	printf("\n");
	
	return 0;
}
