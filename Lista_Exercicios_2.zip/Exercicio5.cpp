/*
GABRIEL_FELIPE_REZENDE_DE_JESUS
5- Fa�a um programa que leia o nome de um vendedor, o seu sal�rio fixo e o total de
vendas efetuadas por ele no m�s (em dinheiro). Sabendo que este vendedor ganha 15%
de comiss�o sobre suas vendas efetuadas, informar o total a receber no final do m�s.
14/03/2023
*/

#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main(void) {
	
	setlocale(LC_ALL, "Portuguese");
	
	char nome [30];
	float salario, vendas, comissao, total;
	
	printf("Informe o nome do vendedor: ");
	scanf(" %[^\n]s",&nome);
	
	printf("Informe o sal�rio (utilize '.' ao inv�s de ',' para decimais): ");
	scanf(" %f",&salario);
	
	printf("Informe o valor das vendas (utilize '.' ao inv�s de ',' para decimais): ");
	scanf(" %f",&vendas);
	
	comissao = vendas*0.15;
	total = salario+comissao;
	
	
	printf("\n");
	printf("TOTAL = %.2f",total);
	printf("\n");
	
	return 0;
}
