/*Gabriel Felipe Rezende de Jesus

1. A prefeitura de uma cidade fez uma pesquisa entre seus habitantes,
coletando dados sobre o sal�rio e o n�mero de filhos. A prefeitura deseja
saber:
a) m�dia salarial da popula��o;
b) m�dia do n�mero de filhos;
c) maior sal�rio;
d) percentual de pessoas com sal�rio at� R$ 100,00.
O final da leitura de dados se dar� com a entrada de um sal�rio negativo.*/ 

#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main(void){
	
	setlocale(LC_ALL, "Portuguese");
	
    float salario, soma_salarios = 0, media_salarios, maior_salario = 0, media_num_filhos;
    int num_filhos, soma_num_filhos = 0, num_pessoas = 0, num_salarios_ate_100 = 0;
    
    printf("Digite o salario e o numero de filhos (separados por espaco) ou um valor negativo para sair:\n");
    scanf("%f %d", &salario, &num_filhos);
    
    while (salario >= 0) {
        soma_salarios += salario;
        soma_num_filhos += num_filhos;
        num_pessoas++;
        
        if (salario > maior_salario) {
            maior_salario = salario;
        }
        
        if (salario <= 100) {
            num_salarios_ate_100++;
        }
        
        printf("Digite o salario e o numero de filhos (separados por espaco) ou um valor negativo para sair:\n");
        scanf("%f %d", &salario, &num_filhos);
    }
    
    media_salarios = soma_salarios / num_pessoas;
    media_num_filhos = soma_num_filhos / num_pessoas;
    float percentual_salarios_ate_100 = (num_salarios_ate_100 * 100) / num_pessoas;
    
    printf("Media salarial da populacao: R$%.2f\n", media_salarios);
    printf("Media do numero de filhos: %.2f\n", media_num_filhos);
    printf("Maior salario: R$%.2f\n", maior_salario);
    printf("Percentual de pessoas com salario ate R$100,00: %.2f%%\n", percentual_salarios_ate_100);
    
    return 0;
}

