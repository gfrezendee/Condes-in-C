/*Gabriel Felipe Rezende de Jesus

2. Chico tem 1,50 metro e cresce 2 cent�metros por ano, enquanto Z� tem 
1,10 metro e cresce 3 cent�metros por ano. Fa�a um programa em C que 
recebendo a altura e o crescimento anual de duas pessoas calcule e 
imprima quantos anos ser�o necess�rios para que a mais baixa seja 
maior que a outra. Caso isto n�o ocorra em 100 anos informar mensagem 
de impossibilidade.
Encerre a entrada de dados quando for digitada uma idade negativa. 
(N�o use vetores ou matrizes).
*/ 

#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main(void){
	
	setlocale(LC_ALL, "Portuguese");
	
	float altura1, altura2;
    int cresc1, cresc2;
    int anos = 0;

	printf("\n\n\t\t***Coloque como primeira pessoa a pessoa mais baixa.*\n\n");
    printf("Digite a altura e o crescimento anual da primeira pessoa (em cm): ");
    scanf("%f %d", &altura1, &cresc1);

    printf("Digite a altura e o crescimento anual da segunda pessoa (em cm): ");
    scanf("%f %d", &altura2, &cresc2);

    while (altura1 <= altura2) {
        if (anos > 100) {
            printf("Impossibilidade de ultrapassagem em 100 anos.\n");
            return 0;
        }

        altura1 += cresc1 / 100.0;
        altura2 += cresc2 / 100.0;
        anos++;
    }

    printf("Serao necessarios %d anos para que a pessoa mais baixa seja maior do que a outra.\n", anos);
	return 0;
}
