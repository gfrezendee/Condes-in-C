/*Gabriel Felipe Rezende de Jesus

4. Elabore um programa que receba como dados de entrada duas notas 
de v�rios alunos e ao final mostra:
a) A quantidade de alunos com media maior ou igual a 7,0;
b) A Menor media da Turma;
c) A Media geral da turma;
d) Quantas vezes o programa rodou;
Observa��o: O programa deve finalizar quando for digitado o valor 0 
(zero) e utilizar no m�ximo 6 vari�veis n�o utilizar vetores ou matrizes.
*/ 

#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main(void){
	
	setlocale(LC_ALL, "Portuguese");
	
    float nota1, nota2, media, media_geral = 0, menor_media = 10;
    int alunos_aprovados = 0, qtd_alunos = 0;

    do {
        printf("Digite as duas notas do aluno (ou 0 para sair):\n");
        scanf("%f %f", &nota1, &nota2);

        if (nota1 != 0 || nota2 != 0) {
            media = (nota1 + nota2) / 2;
            qtd_alunos++;
            media_geral += media;

            if (media >= 7) {
                alunos_aprovados++;
            }

            if (media < menor_media) {
                menor_media = media;
            }
        }
    } while (nota1 != 0 || nota2 != 0);

    if (qtd_alunos == 0) {
        printf("Nenhum aluno informado.\n");
        return 0;
    }

    printf("Quantidade de alunos com m�dia maior ou igual a 7: %d\n", alunos_aprovados);
    printf("Menor m�dia da turma: %.2f\n", menor_media);
    printf("M�dia geral da turma: %.2f\n", media_geral / qtd_alunos);
    printf("Quantidade de vezes que o programa rodou: %d\n", qtd_alunos);

    return 0;
}

