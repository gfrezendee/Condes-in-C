/*Gabriel Felipe Rezende de Jesus

5. Desenvolva um programa que calcula a metragem quadrada de um 
terreno, usando o teste no final para criar a op��o de digitar novos 
valores sem sair do programa.
O programa dever� pedir ao usu�rio para digitar a metragem 1 do terreno, 
a metragem 2 e em seguida mostrar o tamanho total do terreno em 
metros quadrados. O programa dever� perguntar ao usu�rio se ele quer 
continuar para digitar outras metragens ou encerrar o programa.
*/ 

#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main(void){
	
	setlocale(LC_ALL, "Portuguese");
	
	float m1, m2, total;
	char cond;
	
	printf("Deseja calcular a medida de um terreno?(Responda com 's' ou 'n')\n");
	scanf("%s",&cond);
	
	while(cond=='s') {
		printf("Informe as duas medidas do terreno (em metros), separadas por espa�o: ");
		scanf("%f %f",&m1, &m2);
		
		total=m1*m2;
		
		printf("\n\nO tamanho total do terreno �: %.2fm�!",total);
		
		printf("\n\nDeseja saber a medida de outro terreno? (Responda com 's' ou 'n')\n");
		scanf("%s",&cond);	
	}
	
	return 0;
}
