/*Gabriel Felipe Rezende de Jesus

3. Elabore um programa que fa�a o sorteio de v�rios n�meros e ao final 
mostra:
a) A quantidade de n�meros sorteados;
b) O Maior numero sorteado;
c) Quantos n�meros pares foram sorteados;
Observa��o: O programa deve finalizar quando for sorteado o valor 0 
(zero)e utilizar no m�ximo 3 vari�veis n�o utilizar vetores ou matrizes.
*/ 

#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main(void){
	
	setlocale(LC_ALL, "Portuguese");
	
	int num, count = 0, max = 0, count_pares = 0;

    do {
        printf("Digite um numero inteiro (0 para sair): ");
        scanf("%d", &num);

        if (num != 0) {
            count++;

            if (num > max) {
                max = num;
            }

            if (num % 2 == 0) {
                count_pares++;
            }
        }
    } while (num != 0);

    printf("Quantidade de numeros sorteados: %d\n", count);
    printf("Maior numero sorteado: %d\n", max);
    printf("Quantidade de numeros pares sorteados: %d\n", count_pares);

    return 0;
}
